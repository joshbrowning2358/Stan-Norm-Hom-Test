## ----setup, include=FALSE, cache=FALSE, echo=FALSE----------------------------
library(knitr)
opts_chunk$set(fig.path = 'figure/', fig.align = 'center', fig.show = 'hold',
               warning = FALSE, message = FALSE, error = FALSE, tidy = FALSE,
               results = 'markup', eval = TRUE, echo = TRUE, cache = FALSE)
options(replace.assign = TRUE, width = 80)

## ----eval=FALSE---------------------------------------------------------------
#  pairwiseSNHT(data, dist, k, period, crit, returnStat=TRUE/FALSE)

## -----------------------------------------------------------------------------
library(snht)
library(reshape2)
library(ggplot2)

## -----------------------------------------------------------------------------
set.seed(3)
baseData = matrix(rnorm(5000), nrow=1000)
baseData = baseData + cos(1:1000*2*pi/200)
baseData[401:1000, 1] = cos(401:1000*2*pi/200) +
    rnorm(600, mean = 1)

## ----fig = TRUE, echo = FALSE-------------------------------------------------
toPlot = data.frame(baseData)
toPlot$Time = 1:1000
toPlot = melt(toPlot, id.vars = "Time")
toPlot$variable = gsub("X", "Series ", toPlot$variable)
ggplot(toPlot, aes(x = Time)) +
    geom_line(aes(y = value, color = variable)) +
    facet_grid(variable ~ .) + guides(color = FALSE)

## -----------------------------------------------------------------------------
dist<-matrix(0,5,5)
#dist is a symmetric matrix
upper<-matrix(c(rep(0,1),100,100,100,100, rep(0,2),200,141,141,
              rep(0,3),141,141, rep(0,4),200, rep(0,5)), 
              nrow=5,ncol=5)
dist<-t(upper)+upper
colnames(dist)<-rownames(dist)<- paste0("station", 1:5)
dist

## -----------------------------------------------------------------------------
colnames(baseData) <- paste0("station", 1:5)
baseData <- data.frame(time = 1:1000, baseData)
baseData <- melt(baseData, id.vars = "time", variable.name = "location",
                 value.name = "data")

out1 <- pairwiseSNHT(baseData, dist, k=3, period=12, crit=20, returnStat=T)
pairs <- colnames(out1)
pairs
out1[13:15, ]

## ----fig = TRUE, echo = FALSE-------------------------------------------------
par(mfrow=c(4,2),mar=c(1,1,1,1))
for(i in 1:8){
  plot(out1[,i],type="l", ylim=c(0,30),
       xlab="time",ylab="SNHT statistic")
  title(pairs[i], line = -1) 
  abline(h=20, col="red")
}

## -----------------------------------------------------------------------------
out2 <- pairwiseSNHT(baseData, dist, k=3, period=12, crit=20, returnStat=F)
out2$breaks
str(out2$data)

## -----------------------------------------------------------------------------
newPair2 <- out2$data
outNew1 <- pairwiseSNHT(newPair2,dist,k=3,period=12,crit=20,returnStat=T)

## ----fig = TRUE, echo = FALSE-------------------------------------------------
par(mfrow=c(4,2),mar=c(1,1,1,1))
for(i in 1:8){
  plot(outNew1[,i],type="l", ylim=c(0,30),
       xlab="time",ylab="SNHT statistic")
  title(pairs[i], line = -1) 
  abline(h=20, col="red")
}


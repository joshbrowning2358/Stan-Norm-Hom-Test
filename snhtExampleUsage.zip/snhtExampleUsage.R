library(snht)
library(ggplot2)
library(data.table)

## Read and clean up data
d = fread("~/CentralJava_Precipitation.csv")
d[, Date := as.character(Date)]
d[, Date := as.Date(Date, format = "%Y-%m-%d")]
d[, Precipitation := as.numeric(Precipitation)]
d[, DayOfYear := as.numeric(as.character(Date, "%j"))]
setnames(d, old = colnames(d), new = gsub(" ", ".", colnames(d)))

## Plot data
ggplot(d, aes(x = Date, y = Precipitation)) + geom_line() +
    facet_wrap( ~ Station.Name)
ggplot(d, aes(x = DayOfYear, y = Precipitation)) + geom_point(alpha = .3) +
    facet_wrap( ~ Station.Name) + geom_smooth()
ggplot(d, aes(x = DayOfYear, y = Precipitation)) +
    facet_wrap( ~ Station.Name) + geom_smooth()

## Compute SNHT
snhtStatistic = d[, snht(data = Precipitation, period = 365,
                     time = as.numeric(Date), scaled = TRUE,
                     rmSeasonalPeriod = 365, robust = FALSE),
                  by = Station.Name]
snhtStatistic = data.frame(snhtStatistic)

## An alternative way to compute the SNHT, if you're not comfortable with
## the data.table approach.  Basically, you need to make sure you apply the
## snht to each station's data individually.
snhtStatistics = list()
for(station in unique(d$Station.Name)){
    subset = d[d$Station.Name == station, ]
    currentStat = snht(data = subset$Precipitation, period = 365,
                       time = as.numeric(subset$Date), scaled = TRUE,
                       rmSeasonalPeriod = 365, robust = FALSE)
    snhtStatistics = c(snhtStatistics, currentStat)
}
## Now snhtStatistics is a list of length 5, and each element contains a vector
## of the snht statistics for that station.

## Plot the snht statistics for each station
ggplot(snhtStatistic, aes(x = score)) + geom_bar() + 
    facet_wrap( ~ Station.Name)
